SEONautics Website V13
======================

Open index.html in a browser.

V13 improvements
-----------------
- Rebuilt the site structure around five clear paths: Home / Products / Company / Partnership / Quote Inquiry.
- Added a persistent DEMO / CONCEPT disclosure so sample prices, partner cards, and contact addresses are not presented as real business data.
- Added product search and category filters.
- Added product detail modals with Part No., compatibility, usage, and example-price fields.
- Improved cart logic: quantity controls, duplicate-item merging, remove/clear actions, total calculation, and order-request preview.
- Added an inquiry page for engine quotes, parts/tools questions, and partnership proposals.
- Added mobile navigation and responsive layouts.
- Replaced third-party product images with locally bundled SVG illustrations created for this demo.
- Added a local MP4 motion fallback built from the supplied engine-room frame so the homepage remains visually usable without the remote video.
- Retained the Wikimedia engine-room video as the first video source when a network connection is available. Verify the source's current license/attribution terms before public deployment.
- Added accessibility improvements: skip link, meaningful labels, keyboard-close modals, focusable controls, reduced-motion support, and clearer button states.
- Cleaned up the previous V6/V9/V10/V11 version drift and made the README match the current V13 structure.

Important for real deployment
-----------------------------
This remains a static concept/demo site. Replace the .example email addresses, sample prices, sample partner names, sample product identifiers, and demo disclosures with verified business information before public commercial use.

For a production commerce site, connect:
- real product/manufacturer/Part No. data
- stock and delivery status
- order database / CRM
- payment and tax/shipping logic
- company registration information and legal pages
- privacy policy / terms / refund policy
- real partner logos and contract status

Background media
----------------
The homepage keeps a real engine-room video source from Wikimedia Commons first, with the locally bundled assets/engine-room-fallback.mp4 as a fallback. The supplied frame.jpg is also used as a poster/mission visual.
